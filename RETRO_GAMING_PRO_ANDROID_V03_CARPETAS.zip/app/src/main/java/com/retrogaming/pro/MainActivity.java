package com.retrogaming.pro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import android.content.ActivityNotFoundException;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.webkit.JavascriptInterface;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import android.webkit.WebResourceResponse;


public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> pending;
    private static final int PICK_FILES=101, PICK_FOLDER=102;
    private final java.util.Map<String,Uri> folderFiles=new java.util.concurrent.ConcurrentHashMap<>();
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        web=new WebView(this);
        setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void selectFolder(){runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try{startActivityForResult(i,PICK_FOLDER);}catch(Exception ex){Toast.makeText(MainActivity.this,"No se pudo abrir la carpeta",Toast.LENGTH_LONG).show();}
            });}
        },"AndroidFolder");
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                Uri u=request.getUrl();
                if("rgp.local".equals(u.getHost()) && u.getPath()!=null && u.getPath().startsWith("/rom/")){
                    Uri file=folderFiles.get(u.getLastPathSegment());
                    if(file==null)return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));
                    try{InputStream in=getContentResolver().openInputStream(file);return new WebResourceResponse("application/octet-stream",null,in);}
                    catch(Exception ex){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));}
                }
                return super.shouldInterceptRequest(view,request);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri u=request.getUrl();
                String scheme=u.getScheme();
                if (scheme!=null && (scheme.equals("https") || scheme.equals("http"))){
                    try {startActivity(new Intent(Intent.ACTION_VIEW,u));}
                    catch(ActivityNotFoundException ex){Toast.makeText(MainActivity.this,"No hay navegador disponible",Toast.LENGTH_LONG).show();}
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(pending!=null)pending.onReceiveValue(null);
                pending=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try{startActivityForResult(i,PICK_FILES);}catch(Exception ex){pending.onReceiveValue(null);pending=null;Toast.makeText(MainActivity.this,"No se pudo abrir el selector",Toast.LENGTH_LONG).show();}
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==PICK_FOLDER){
            if(result==RESULT_OK && data!=null && data.getData()!=null){
                Uri tree=data.getData();
                try{getContentResolver().takePersistableUriPermission(tree,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                folderFiles.clear();JSONArray arr=new JSONArray();
                try{walkFolder(tree,DocumentsContract.getTreeDocumentId(tree),arr,0);
                    String json=arr.toString();web.evaluateJavascript("window.receiveAndroidFolder("+json+")",null);
                }catch(Exception ex){Toast.makeText(this,"Error leyendo carpeta: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            }
            return;
        }
        if(req!=PICK_FILES||pending==null)return;
        Uri[] selected=null;
        if(result==RESULT_OK&&data!=null){
            if(data.getClipData()!=null){
                int count=data.getClipData().getItemCount();
                selected=new Uri[count];
                for(int i=0;i<count;i++)selected[i]=data.getClipData().getItemAt(i).getUri();
            }else if(data.getData()!=null)selected=new Uri[]{data.getData()};
        }
        pending.onReceiveValue(selected);
        pending=null;
    }
    private void walkFolder(Uri tree,String parent,JSONArray output,int depth) throws Exception {
        if(depth>12 || output.length()>=3000)return;
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
        try(Cursor c=getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE},null,null,null)){
            if(c==null)return;
            while(c.moveToNext() && output.length()<3000){
                String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){walkFolder(tree,id,output,depth+1);continue;}
                if(name==null || !name.matches("(?i).*\\.(nes|sfc|smc|gb|gbc|gba|z64|n64|v64|gen|md|smd|cue|chd|pbp|iso|cso|bin|zip|7z)$"))continue;
                String token="f"+folderFiles.size();
                folderFiles.put(token,DocumentsContract.buildDocumentUriUsingTree(tree,id));
                JSONObject o=new JSONObject();o.put("name",name);o.put("url","https://rgp.local/rom/"+token);o.put("size",c.isNull(3)?0:c.getLong(3));output.put(o);
            }
        }
    }
    @Override public void onBackPressed(){
        web.evaluateJavascript("document.getElementById('play').classList.contains('show')",value->{
            if("true".equals(value))web.evaluateJavascript("document.getElementById('px').click()",null);
            else if(web.canGoBack())web.goBack();else MainActivity.super.onBackPressed();
        });
    }
    @Override protected void onDestroy(){
        if(pending!=null){pending.onReceiveValue(null);pending=null;}
        if(web!=null){web.destroy();web=null;}
        super.onDestroy();
    }
}
